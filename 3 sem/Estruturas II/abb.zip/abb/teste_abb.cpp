#include <iostream.h>
#include "abb.h"

void main() {
  arvore t;
  celula *q;
  int x;

  inicializa_arvore(&t);
  do {
    /* Busca elementos em uma �rvore, removendo se 
       acha e inserindo se n�o acha, at� digitarem 0. */
    cout << "Digite x: ";
    cin >> x;
    if ((q=busca(&t, x)) == NULL) {
      cout << endl << "Nao achou!" << endl;
      insere(&t, x);
    }
    else {
      cout << endl << "Achou!" << endl;
      remove(&t, q);
    }
    imprime(t.raiz, 0);
  } while (x != 0);
}
